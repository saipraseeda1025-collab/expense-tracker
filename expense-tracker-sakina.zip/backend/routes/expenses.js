const express = require("express");
const Expense = require("../models/Expense");
//@ts-ignore
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Add expense
router.post("/", authMiddleware, async (req, res) => {
  const { title, amount, date } = req.body;

  try {
    const expense = new Expense({
      title,
      amount,
      date,
      user: req.user.id
    });

    await expense.save();
    res.status(201).json({ message: "Expense added", expense });
  } catch (err) {
    res.status(500).json({ message: "Error adding expense" });
  }
});

// Get expenses
router.get("/", authMiddleware, async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user.id });
    res.json(expenses);
  } catch (err) {
    res.status(500).json({ message: "Error fetching expenses" });
  }
});

// ✅ UPDATE expense (EDIT)
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const updatedExpense = await Expense.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true } // 🔥 VERY IMPORTANT
    );

    if (!updatedExpense) {
      return res.status(404).json({ message: "Expense not found" });
    }

    res.json(updatedExpense);
  } catch (err) {
    res.status(500).json({ message: "Error updating expense" });
  }
});

// Delete expense
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    await Expense.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });
    res.json({ message: "Expense deleted" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting expense" });
  }
});

module.exports = router;
