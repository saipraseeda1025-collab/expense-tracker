require("dotenv").config();
console.log("MONGO_URI:", process.env.MONGO_URI);

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();

// ✅ FIX: Allow Authorization header
app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log("MongoDB connection error:", err));

// Test route
app.get("/", (req, res) => {
  res.send("Expense Tracker Backend Running");
});

// Routes
app.use("/auth", require("./routes/auth"));
app.use("/expenses", require("./routes/expenses"));

// Start server
app.listen(5000, () => {
  console.log("Server running on port 5000");
});
